import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  Shield, AlertTriangle, Activity, Server, 
  Clock, TrendingUp, Eye, Bell
} from 'lucide-react';

import HUDBackground from '@/components/dashboard/HUDBackground';
import StatCard from '@/components/dashboard/StatCard';
import AlertsPanel from '@/components/dashboard/AlertsPanel';
import LogStream from '@/components/dashboard/LogStream';
import GlobeVisualization from '@/components/dashboard/GlobeVisualization';
import ThreatChart from '@/components/dashboard/ThreatChart';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const { data: alerts = [] } = useQuery({
    queryKey: ['alerts'],
    queryFn: () => base44.entities.Alert.list('-created_date', 20),
  });

  const { data: logs = [] } = useQuery({
    queryKey: ['logs'],
    queryFn: () => base44.entities.SecurityLog.list('-timestamp', 30),
  });

  const { data: incidents = [] } = useQuery({
    queryKey: ['incidents'],
    queryFn: () => base44.entities.Incident.list('-created_date', 10),
  });

  const stats = {
    criticalAlerts: alerts.filter(a => a.severity === 'critical').length,
    highAlerts: alerts.filter(a => a.severity === 'high').length,
    activeIncidents: incidents.filter(i => i.status !== 'closed' && i.status !== 'resolved').length,
    totalLogs: logs.length,
  };

  return (
    <div className="min-h-screen relative">
      <HUDBackground />
      
      <div className="relative z-10 p-4 md:p-6 lg:p-8 max-w-[1800px] mx-auto">
        {/* Header */}
        <motion.div
          className="flex flex-col md:flex-row md:items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-white flex items-center gap-3">
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              >
                <Shield className="w-8 h-8 text-purple-400" />
              </motion.div>
              Security Operations Center
            </h1>
            <p className="text-gray-400 mt-1">Real-time monitoring & threat detection</p>
          </div>
          
          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <motion.div
              className="flex items-center gap-2 px-4 py-2 bg-green-500/20 rounded-full border border-green-500/40"
              animate={{ opacity: [1, 0.7, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <span className="w-2 h-2 rounded-full bg-green-400" />
              <span className="text-green-400 text-sm font-medium">SYSTEM ACTIVE</span>
            </motion.div>
            <div className="flex items-center gap-2 text-gray-400 text-sm">
              <Clock className="w-4 h-4" />
              {currentTime.toLocaleTimeString()}
            </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={AlertTriangle}
            label="Critical Alerts"
            value={stats.criticalAlerts}
            color="red"
            trend={12}
          />
          <StatCard
            icon={Bell}
            label="High Priority"
            value={stats.highAlerts}
            color="yellow"
            trend={-5}
          />
          <StatCard
            icon={Activity}
            label="Active Incidents"
            value={stats.activeIncidents}
            color="purple"
          />
          <StatCard
            icon={Eye}
            label="Logs Monitored"
            value={stats.totalLogs}
            color="cyan"
            trend={8}
          />
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Alerts */}
          <div className="lg:col-span-1">
            <AlertsPanel 
              alerts={alerts} 
              onAlertClick={(alert) => {
                window.location.href = createPageUrl('Alerts');
              }}
            />
          </div>

          {/* Middle Column - Chart & Globe */}
          <div className="lg:col-span-1 space-y-6">
            <GlobeVisualization threats={alerts} />
            <ThreatChart />
          </div>

          {/* Right Column - Log Stream */}
          <div className="lg:col-span-1">
            <LogStream logs={logs} />
          </div>
        </div>

        {/* Quick Actions */}
        <motion.div
          className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          {[
            { label: 'View Alerts', page: 'Alerts', icon: AlertTriangle, color: 'red' },
            { label: 'Incidents', page: 'Incidents', icon: Shield, color: 'purple' },
            { label: 'Log Analysis', page: 'Logs', icon: Server, color: 'cyan' },
            { label: 'Reports', page: 'Reports', icon: TrendingUp, color: 'green' },
          ].map((action, i) => (
            <Link key={action.page} to={createPageUrl(action.page)}>
              <motion.div
                className={`p-4 rounded-xl bg-black/40 border border-${action.color}-500/30 backdrop-blur-sm cursor-pointer hover:border-${action.color}-500/60 transition-all`}
                whileHover={{ scale: 1.02, y: -2 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i }}
              >
                <action.icon className={`w-6 h-6 text-${action.color}-400 mb-2`} />
                <span className="text-white font-medium">{action.label}</span>
              </motion.div>
            </Link>
          ))}
        </motion.div>
      </div>
    </div>
  );
}