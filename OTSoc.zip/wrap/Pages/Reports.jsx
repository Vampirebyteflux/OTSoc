import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  FileText, Download, Search, Calendar,
  PieChart, BarChart3, TrendingUp
} from 'lucide-react';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';
import { PieChart as RechartsPie, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

import HUDBackground from '@/components/dashboard/HUDBackground';
import ReportViewer from '@/components/reports/ReportViewer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';

const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e'];

export default function Reports() {
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [dateRange, setDateRange] = useState('7d');

  const { data: incidents = [] } = useQuery({
    queryKey: ['incidents'],
    queryFn: () => base44.entities.Incident.list('-created_date', 100),
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ['alerts'],
    queryFn: () => base44.entities.Alert.list('-created_date', 100),
  });

  // Calculate stats
  const severityData = ['critical', 'high', 'medium', 'low'].map((sev, i) => ({
    name: sev,
    value: incidents.filter(inc => inc.severity === sev).length,
    color: COLORS[i],
  }));

  const statusData = ['open', 'in_progress', 'contained', 'resolved', 'closed'].map(status => ({
    name: status.replace('_', ' '),
    incidents: incidents.filter(inc => inc.status === status).length,
    alerts: alerts.filter(a => a.status === status || (status === 'open' && a.status === 'new')).length,
  }));

  const typeData = Object.entries(
    incidents.reduce((acc, inc) => {
      const type = inc.incident_type || 'other';
      acc[type] = (acc[type] || 0) + 1;
      return acc;
    }, {})
  ).map(([name, value]) => ({ name: name.replace(/_/g, ' '), value }));

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-black/90 border border-purple-500/30 rounded-lg p-3 backdrop-blur-sm">
          <p className="text-white text-sm capitalize">{payload[0].name}</p>
          <p className="text-purple-400 font-semibold">{payload[0].value}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen relative">
      <HUDBackground />
      
      <div className="relative z-10 p-4 md:p-6 lg:p-8 max-w-[1600px] mx-auto">
        {/* Header */}
        <motion.div
          className="flex flex-col md:flex-row md:items-center justify-between mb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3">
            <FileText className="w-8 h-8 text-cyan-400" />
            <div>
              <h1 className="text-2xl font-bold text-white">Reports & Analytics</h1>
              <p className="text-gray-400 text-sm">Security metrics and incident reports</p>
            </div>
          </div>
          
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40 bg-black/30 border-gray-700 text-white mt-4 md:mt-0">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24 Hours</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
              <SelectItem value="90d">Last 90 Days</SelectItem>
            </SelectContent>
          </Select>
        </motion.div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Incidents', value: incidents.length, icon: FileText, color: 'purple' },
            { label: 'Critical', value: incidents.filter(i => i.severity === 'critical').length, icon: TrendingUp, color: 'red' },
            { label: 'Open', value: incidents.filter(i => i.status === 'open').length, icon: BarChart3, color: 'yellow' },
            { label: 'Resolved', value: incidents.filter(i => i.status === 'resolved' || i.status === 'closed').length, icon: PieChart, color: 'green' },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              className={`p-5 rounded-xl bg-black/40 border border-${stat.color}-500/30 backdrop-blur-sm`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <stat.icon className={`w-6 h-6 text-${stat.color}-400 mb-2`} />
              <p className="text-2xl font-bold text-white">{stat.value}</p>
              <p className="text-gray-400 text-sm">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Severity Distribution */}
          <motion.div
            className="bg-black/40 backdrop-blur-sm border border-purple-500/20 rounded-xl p-5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <h3 className="text-lg font-semibold text-white mb-4">Severity Distribution</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPie>
                  <Pie
                    data={severityData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {severityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </RechartsPie>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {severityData.map((item) => (
                <div key={item.name} className="flex items-center gap-2 text-xs">
                  <span className="w-3 h-3 rounded" style={{ backgroundColor: item.color }} />
                  <span className="text-gray-400 capitalize">{item.name}: {item.value}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Status Overview */}
          <motion.div
            className="bg-black/40 backdrop-blur-sm border border-purple-500/20 rounded-xl p-5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            <h3 className="text-lg font-semibold text-white mb-4">Status Overview</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={statusData}>
                  <XAxis 
                    dataKey="name" 
                    stroke="#6b7280" 
                    tick={{ fill: '#9ca3af', fontSize: 10 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis stroke="#6b7280" tick={{ fill: '#9ca3af', fontSize: 11 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="incidents" fill="#a855f7" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Incident Types */}
          <motion.div
            className="bg-black/40 backdrop-blur-sm border border-purple-500/20 rounded-xl p-5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <h3 className="text-lg font-semibold text-white mb-4">Incident Types</h3>
            <div className="space-y-3">
              {typeData.map((type, i) => {
                const max = Math.max(...typeData.map(t => t.value)) || 1;
                const percentage = (type.value / max) * 100;
                return (
                  <div key={type.name}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-400 capitalize">{type.name}</span>
                      <span className="text-white">{type.value}</span>
                    </div>
                    <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${percentage}%` }}
                        transition={{ delay: 0.3 + i * 0.1, duration: 0.5 }}
                      />
                    </div>
                  </div>
                );
              })}
              {typeData.length === 0 && (
                <p className="text-gray-500 text-center py-8">No incident data</p>
              )}
            </div>
          </motion.div>
        </div>

        {/* Recent Incidents for Report */}
        <motion.div
          className="bg-black/40 backdrop-blur-sm border border-purple-500/20 rounded-xl p-5"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-lg font-semibold text-white mb-4">Recent Incidents</h3>
          <div className="space-y-3">
            {incidents.slice(0, 10).map((incident, i) => (
              <motion.div
                key={incident.id}
                className="p-4 bg-black/30 rounded-lg border border-gray-800 hover:border-purple-500/30 cursor-pointer transition-all"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * i }}
                whileHover={{ x: 5 }}
                onClick={() => setSelectedIncident(incident)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-gray-500 font-mono text-xs">
                        {incident.incident_id || `INC-${incident.id?.slice(0, 6)}`}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-xs uppercase ${
                        incident.severity === 'critical' ? 'bg-red-500/20 text-red-400' :
                        incident.severity === 'high' ? 'bg-orange-500/20 text-orange-400' :
                        incident.severity === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>
                        {incident.severity}
                      </span>
                    </div>
                    <p className="text-white">{incident.title}</p>
                    <p className="text-gray-500 text-sm">{format(new Date(incident.created_date), 'MMM d, yyyy HH:mm')}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-purple-400"
                  >
                    View Report
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Report Sheet */}
      <Sheet open={!!selectedIncident} onOpenChange={() => setSelectedIncident(null)}>
        <SheetContent className="bg-[#0a0a1a] border-purple-500/30 w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="text-white">Incident Report</SheetTitle>
          </SheetHeader>
          <div className="mt-6">
            <ReportViewer incident={selectedIncident} />
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}