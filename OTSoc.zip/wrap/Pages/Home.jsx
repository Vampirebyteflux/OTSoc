import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import CinematicIntro from '@/components/intro/CinematicIntro';

export default function Home() {
  const [showIntro, setShowIntro] = useState(true);
  const [introComplete, setIntroComplete] = useState(false);

  useEffect(() => {
    // Check if intro was already shown in this session
    const introShown = sessionStorage.getItem('otsoc_intro_shown');
    if (introShown) {
      setShowIntro(false);
      setIntroComplete(true);
    }
  }, []);

  const handleIntroComplete = () => {
    sessionStorage.setItem('otsoc_intro_shown', 'true');
    setShowIntro(false);
    setIntroComplete(true);
  };

  // Redirect to dashboard after intro
  useEffect(() => {
    if (introComplete) {
      window.location.href = '/Dashboard';
    }
  }, [introComplete]);

  return (
    <div className="min-h-screen bg-black">
      <AnimatePresence>
        {showIntro && (
          <CinematicIntro onComplete={handleIntroComplete} />
        )}
      </AnimatePresence>
      
      {!showIntro && !introComplete && (
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-purple-400 animate-pulse">Loading...</div>
        </div>
      )}
    </div>
  );
}