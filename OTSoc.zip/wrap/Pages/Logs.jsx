import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Terminal, Search, Filter, Server, Shield, 
  Cloud, Laptop, Globe, Clock, RefreshCw
} from 'lucide-react';
import { format } from 'date-fns';

import HUDBackground from '@/components/dashboard/HUDBackground';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const sourceIcons = {
  firewall: Shield,
  endpoint: Laptop,
  server: Server,
  cloud: Cloud,
  application: Globe,
};

const eventColors = {
  login_failure: 'text-red-400 bg-red-500/20',
  login_success: 'text-green-400 bg-green-500/20',
  malware_detected: 'text-red-500 bg-red-500/30',
  suspicious_traffic: 'text-yellow-400 bg-yellow-500/20',
  access_denied: 'text-orange-400 bg-orange-500/20',
  privilege_escalation: 'text-purple-400 bg-purple-500/20',
  data_exfiltration: 'text-red-600 bg-red-500/30',
};

export default function Logs() {
  const [filters, setFilters] = useState({ source: 'all', event_type: 'all', search: '' });

  const { data: logs = [], isLoading, refetch } = useQuery({
    queryKey: ['logs'],
    queryFn: () => base44.entities.SecurityLog.list('-timestamp', 200),
  });

  const filteredLogs = logs.filter(log => {
    if (filters.source !== 'all' && log.source !== filters.source) return false;
    if (filters.event_type !== 'all' && log.event_type !== filters.event_type) return false;
    if (filters.search) {
      const search = filters.search.toLowerCase();
      return log.user?.toLowerCase().includes(search) || 
             log.source_ip?.toLowerCase().includes(search) ||
             log.raw_log?.toLowerCase().includes(search);
    }
    return true;
  });

  const logCounts = {
    total: logs.length,
    bySource: logs.reduce((acc, l) => {
      acc[l.source] = (acc[l.source] || 0) + 1;
      return acc;
    }, {}),
  };

  return (
    <div className="min-h-screen relative">
      <HUDBackground />
      
      <div className="relative z-10 p-4 md:p-6 lg:p-8 max-w-[1600px] mx-auto">
        {/* Header */}
        <motion.div
          className="flex flex-col md:flex-row md:items-center justify-between mb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3">
            <motion.div
              animate={{ opacity: [1, 0.5, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            >
              <Terminal className="w-8 h-8 text-green-400" />
            </motion.div>
            <div>
              <h1 className="text-2xl font-bold text-white">Log Analysis</h1>
              <p className="text-gray-400 text-sm">{filteredLogs.length} logs displayed</p>
            </div>
          </div>
          
          <Button
            variant="outline"
            onClick={() => refetch()}
            className="border-purple-500/40 text-purple-400 hover:bg-purple-500/20 mt-4 md:mt-0"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </motion.div>

        {/* Source Stats */}
        <motion.div
          className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          {Object.entries(sourceIcons).map(([source, Icon]) => (
            <motion.div
              key={source}
              className={`p-4 rounded-xl bg-black/40 border backdrop-blur-sm cursor-pointer transition-all ${
                filters.source === source 
                  ? 'border-purple-500 bg-purple-500/20' 
                  : 'border-gray-800 hover:border-purple-500/50'
              }`}
              whileHover={{ scale: 1.02 }}
              onClick={() => setFilters({ ...filters, source: filters.source === source ? 'all' : source })}
            >
              <Icon className="w-5 h-5 text-purple-400 mb-2" />
              <p className="text-white font-semibold">{logCounts.bySource[source] || 0}</p>
              <p className="text-gray-400 text-xs capitalize">{source}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Filters */}
        <motion.div
          className="bg-black/40 backdrop-blur-sm border border-purple-500/20 rounded-xl p-4 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex items-center gap-2 flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search logs..."
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                className="bg-black/30 border-gray-700 text-white"
              />
            </div>

            <Select value={filters.event_type} onValueChange={(v) => setFilters({ ...filters, event_type: v })}>
              <SelectTrigger className="w-48 bg-black/30 border-gray-700 text-white">
                <SelectValue placeholder="Event Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Events</SelectItem>
                <SelectItem value="login_failure">Login Failure</SelectItem>
                <SelectItem value="login_success">Login Success</SelectItem>
                <SelectItem value="malware_detected">Malware Detected</SelectItem>
                <SelectItem value="suspicious_traffic">Suspicious Traffic</SelectItem>
                <SelectItem value="access_denied">Access Denied</SelectItem>
                <SelectItem value="privilege_escalation">Privilege Escalation</SelectItem>
                <SelectItem value="data_exfiltration">Data Exfiltration</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        {/* Logs Table */}
        <motion.div
          className="bg-black/40 backdrop-blur-sm border border-purple-500/20 rounded-xl overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-black/50">
                <tr className="text-left text-gray-400 text-xs uppercase">
                  <th className="p-4">Time</th>
                  <th className="p-4">Source</th>
                  <th className="p-4">Event</th>
                  <th className="p-4">User</th>
                  <th className="p-4">Source IP</th>
                  <th className="p-4">Location</th>
                  <th className="p-4">Details</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence>
                  {filteredLogs.slice(0, 50).map((log, index) => {
                    const Icon = sourceIcons[log.source] || Server;
                    return (
                      <motion.tr
                        key={log.id}
                        className="border-t border-gray-800 hover:bg-purple-500/5 transition-colors"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ delay: index * 0.02 }}
                      >
                        <td className="p-4">
                          <span className="text-gray-400 text-sm font-mono">
                            {format(new Date(log.timestamp), 'HH:mm:ss')}
                          </span>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <Icon className="w-4 h-4 text-gray-500" />
                            <span className="text-purple-400 text-sm capitalize">{log.source}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className={`px-2 py-1 rounded text-xs ${eventColors[log.event_type] || 'text-gray-400 bg-gray-500/20'}`}>
                            {log.event_type?.replace(/_/g, ' ')}
                          </span>
                        </td>
                        <td className="p-4 text-white text-sm">{log.user || '-'}</td>
                        <td className="p-4 text-gray-400 text-sm font-mono">{log.source_ip || '-'}</td>
                        <td className="p-4 text-gray-400 text-sm">{log.country || '-'}</td>
                        <td className="p-4 text-gray-500 text-sm max-w-[200px] truncate">
                          {log.raw_log || '-'}
                        </td>
                      </motion.tr>
                    );
                  })}
                </AnimatePresence>
              </tbody>
            </table>
          </div>

          {filteredLogs.length === 0 && (
            <div className="text-center py-16">
              <Terminal className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No logs match your filters</p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}