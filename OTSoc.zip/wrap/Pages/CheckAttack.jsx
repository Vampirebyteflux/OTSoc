import React from 'react';
import { motion } from 'framer-motion';
import { Zap, AlertTriangle, Shield } from 'lucide-react';

import HUDBackground from '@/components/dashboard/HUDBackground';
import AttackSimulator from '@/components/attack/AttackSimulator';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function CheckAttack() {
  return (
    <div className="min-h-screen relative">
      <HUDBackground />
      
      <div className="relative z-10 p-4 md:p-6 lg:p-8 max-w-[1600px] mx-auto">
        {/* Header */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3 mb-4">
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, 180, 360],
              }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Zap className="w-8 h-8 text-red-400" />
            </motion.div>
            <div>
              <h1 className="text-2xl font-bold text-white">Attack Simulator</h1>
              <p className="text-gray-400 text-sm">Test your SOC's detection and response capabilities</p>
            </div>
          </div>

          {/* Warning Banner */}
          <Alert className="bg-red-500/10 border-red-500/50">
            <AlertTriangle className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-red-300">
              <strong>Testing Environment Only:</strong> This simulator generates synthetic attack data for testing SOC detection capabilities. 
              All generated events are clearly marked as simulated and will trigger alerts in the system.
            </AlertDescription>
          </Alert>
        </motion.div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <motion.div
            className="p-5 rounded-xl bg-black/40 border border-purple-500/30 backdrop-blur-sm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Shield className="w-8 h-8 text-purple-400 mb-3" />
            <h3 className="text-white font-semibold mb-2">Safe Testing</h3>
            <p className="text-gray-400 text-sm">
              Simulations generate synthetic data without affecting real systems
            </p>
          </motion.div>

          <motion.div
            className="p-5 rounded-xl bg-black/40 border border-cyan-500/30 backdrop-blur-sm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Zap className="w-8 h-8 text-cyan-400 mb-3" />
            <h3 className="text-white font-semibold mb-2">Real Alerts</h3>
            <p className="text-gray-400 text-sm">
              Generated events trigger actual alerts for response testing
            </p>
          </motion.div>

          <motion.div
            className="p-5 rounded-xl bg-black/40 border border-green-500/30 backdrop-blur-sm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <AlertTriangle className="w-8 h-8 text-green-400 mb-3" />
            <h3 className="text-white font-semibold mb-2">Detection Training</h3>
            <p className="text-gray-400 text-sm">
              Perfect for training analysts and testing detection rules
            </p>
          </motion.div>
        </div>

        {/* Attack Simulator */}
        <AttackSimulator />
      </div>
    </div>
  );
}