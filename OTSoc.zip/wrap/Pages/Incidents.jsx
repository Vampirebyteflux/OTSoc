import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Shield, Plus, Search, Filter, X
} from 'lucide-react';

import HUDBackground from '@/components/dashboard/HUDBackground';
import IncidentCard from '@/components/incidents/IncidentCard';
import ReportViewer from '@/components/reports/ReportViewer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';

export default function Incidents() {
  const [filters, setFilters] = useState({ severity: 'all', status: 'all', search: '' });
  const [showCreate, setShowCreate] = useState(false);
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    incident_type: 'security_breach',
    severity: 'medium',
    status: 'open',
    affected_systems: '',
    source_ip: '',
    impact: '',
    actions_taken: '',
    recommendations: '',
    assigned_to: '',
  });

  const queryClient = useQueryClient();

  const { data: incidents = [], isLoading } = useQuery({
    queryKey: ['incidents'],
    queryFn: () => base44.entities.Incident.list('-created_date', 100),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Incident.create({
      ...data,
      incident_id: `INC-${Date.now().toString(36).toUpperCase()}`,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['incidents']);
      setShowCreate(false);
      setFormData({
        title: '',
        incident_type: 'security_breach',
        severity: 'medium',
        status: 'open',
        affected_systems: '',
        source_ip: '',
        impact: '',
        actions_taken: '',
        recommendations: '',
        assigned_to: '',
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Incident.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['incidents']);
    },
  });

  const filteredIncidents = incidents.filter(incident => {
    if (filters.severity !== 'all' && incident.severity !== filters.severity) return false;
    if (filters.status !== 'all' && incident.status !== filters.status) return false;
    if (filters.search) {
      const search = filters.search.toLowerCase();
      return incident.title?.toLowerCase().includes(search) || 
             incident.incident_id?.toLowerCase().includes(search);
    }
    return true;
  });

  return (
    <div className="min-h-screen relative">
      <HUDBackground />
      
      <div className="relative z-10 p-4 md:p-6 lg:p-8 max-w-[1600px] mx-auto">
        {/* Header */}
        <motion.div
          className="flex flex-col md:flex-row md:items-center justify-between mb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-purple-400" />
            <div>
              <h1 className="text-2xl font-bold text-white">Incident Management</h1>
              <p className="text-gray-400 text-sm">{filteredIncidents.length} incidents</p>
            </div>
          </div>
          
          <Button
            onClick={() => setShowCreate(true)}
            className="bg-purple-600 hover:bg-purple-700 mt-4 md:mt-0"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Incident
          </Button>
        </motion.div>

        {/* Filters */}
        <motion.div
          className="bg-black/40 backdrop-blur-sm border border-purple-500/20 rounded-xl p-4 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex items-center gap-2 flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search incidents..."
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                className="bg-black/30 border-gray-700 text-white"
              />
            </div>
            
            <Select value={filters.severity} onValueChange={(v) => setFilters({ ...filters, severity: v })}>
              <SelectTrigger className="w-40 bg-black/30 border-gray-700 text-white">
                <SelectValue placeholder="Severity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Severity</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.status} onValueChange={(v) => setFilters({ ...filters, status: v })}>
              <SelectTrigger className="w-40 bg-black/30 border-gray-700 text-white">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="open">Open</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="contained">Contained</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        {/* Incidents Grid */}
        <div className="grid gap-4">
          <AnimatePresence>
            {filteredIncidents.map((incident, index) => (
              <motion.div
                key={incident.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <IncidentCard
                  incident={incident}
                  onView={(inc) => setSelectedIncident(inc)}
                  onShare={(inc) => setSelectedIncident(inc)}
                />
              </motion.div>
            ))}
          </AnimatePresence>

          {filteredIncidents.length === 0 && (
            <motion.div
              className="text-center py-16"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <Shield className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No incidents found</p>
            </motion.div>
          )}
        </div>
      </div>

      {/* Create Incident Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="bg-[#0a0a1a] border-purple-500/30 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Incident</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <Input
              placeholder="Incident Title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="bg-black/30 border-gray-700"
            />
            
            <div className="grid grid-cols-2 gap-4">
              <Select value={formData.incident_type} onValueChange={(v) => setFormData({ ...formData, incident_type: v })}>
                <SelectTrigger className="bg-black/30 border-gray-700">
                  <SelectValue placeholder="Incident Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="security_breach">Security Breach</SelectItem>
                  <SelectItem value="malware_infection">Malware Infection</SelectItem>
                  <SelectItem value="unauthorized_access">Unauthorized Access</SelectItem>
                  <SelectItem value="data_leak">Data Leak</SelectItem>
                  <SelectItem value="ddos_attack">DDoS Attack</SelectItem>
                  <SelectItem value="phishing">Phishing</SelectItem>
                  <SelectItem value="insider_threat">Insider Threat</SelectItem>
                </SelectContent>
              </Select>

              <Select value={formData.severity} onValueChange={(v) => setFormData({ ...formData, severity: v })}>
                <SelectTrigger className="bg-black/30 border-gray-700">
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Input
              placeholder="Affected Systems (comma-separated)"
              value={formData.affected_systems}
              onChange={(e) => setFormData({ ...formData, affected_systems: e.target.value })}
              className="bg-black/30 border-gray-700"
            />

            <Input
              placeholder="Source IP Address"
              value={formData.source_ip}
              onChange={(e) => setFormData({ ...formData, source_ip: e.target.value })}
              className="bg-black/30 border-gray-700"
            />

            <Textarea
              placeholder="Impact Description"
              value={formData.impact}
              onChange={(e) => setFormData({ ...formData, impact: e.target.value })}
              className="bg-black/30 border-gray-700 min-h-[80px]"
            />

            <Textarea
              placeholder="Actions Taken"
              value={formData.actions_taken}
              onChange={(e) => setFormData({ ...formData, actions_taken: e.target.value })}
              className="bg-black/30 border-gray-700 min-h-[80px]"
            />

            <Textarea
              placeholder="Recommendations"
              value={formData.recommendations}
              onChange={(e) => setFormData({ ...formData, recommendations: e.target.value })}
              className="bg-black/30 border-gray-700 min-h-[80px]"
            />

            <Input
              placeholder="Assigned To"
              value={formData.assigned_to}
              onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
              className="bg-black/30 border-gray-700"
            />

            <Button
              onClick={() => createMutation.mutate(formData)}
              disabled={!formData.title || createMutation.isPending}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              {createMutation.isPending ? 'Creating...' : 'Create Incident'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Incident Detail Sheet */}
      <Sheet open={!!selectedIncident} onOpenChange={() => setSelectedIncident(null)}>
        <SheetContent className="bg-[#0a0a1a] border-purple-500/30 w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="text-white">Incident Details</SheetTitle>
          </SheetHeader>
          <div className="mt-6">
            <ReportViewer incident={selectedIncident} />
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}