import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Zap, Shield, Server, Globe, Laptop, Bug, 
  Wifi, Lock, AlertTriangle, Play, Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';

const attackTypes = [
  {
    id: 'brute_force',
    name: 'Brute Force Attack',
    icon: Lock,
    color: 'red',
    description: 'Simulate multiple failed login attempts',
    targets: ['firewall', 'endpoint', 'server'],
  },
  {
    id: 'malware',
    name: 'Malware Injection',
    icon: Bug,
    color: 'purple',
    description: 'Simulate malware detection scenario',
    targets: ['endpoint', 'server'],
  },
  {
    id: 'ddos',
    name: 'DDoS Attack',
    icon: Wifi,
    color: 'orange',
    description: 'Simulate distributed denial of service',
    targets: ['firewall', 'server', 'cloud'],
  },
  {
    id: 'port_scan',
    name: 'Port Scanning',
    icon: Globe,
    color: 'yellow',
    description: 'Simulate network reconnaissance',
    targets: ['firewall', 'server'],
  },
  {
    id: 'privilege_escalation',
    name: 'Privilege Escalation',
    icon: Shield,
    color: 'red',
    description: 'Simulate unauthorized privilege increase',
    targets: ['server', 'endpoint'],
  },
  {
    id: 'data_exfiltration',
    name: 'Data Exfiltration',
    icon: Server,
    color: 'red',
    description: 'Simulate unauthorized data transfer',
    targets: ['server', 'cloud'],
  },
];

export default function AttackSimulator({ onComplete }) {
  const [selectedAttack, setSelectedAttack] = useState(null);
  const [config, setConfig] = useState({
    target: '',
    targetIp: '',
    intensity: 'medium',
    duration: '5',
    customPayload: '',
  });
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  const queryClient = useQueryClient();

  const generateAttackData = (attack) => {
    const now = new Date();
    const logs = [];
    const alerts = [];
    
    const targetIp = config.targetIp || `192.168.1.${Math.floor(Math.random() * 254) + 1}`;
    const sourceIp = `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
    const countries = ['China', 'Russia', 'North Korea', 'Iran', 'Unknown'];
    const country = countries[Math.floor(Math.random() * countries.length)];

    switch (attack.id) {
      case 'brute_force':
        for (let i = 0; i < 15; i++) {
          logs.push({
            timestamp: new Date(now.getTime() - (15 - i) * 1000).toISOString(),
            source: config.target || 'firewall',
            event_type: 'login_failure',
            user: 'admin',
            source_ip: sourceIp,
            destination_ip: targetIp,
            country: country,
            raw_log: `Failed login attempt ${i + 1} from ${sourceIp}`,
          });
        }
        alerts.push({
          title: 'Simulated Brute Force Attack Detected',
          description: `15 failed login attempts detected from ${sourceIp} in ${config.duration} seconds. Source: ${country}. Target: ${config.target}`,
          severity: 'critical',
          status: 'new',
          alert_type: 'brute_force',
          source_ip: sourceIp,
          affected_user: 'admin',
          country: country,
          priority_score: 95,
        });
        break;

      case 'malware':
        logs.push({
          timestamp: now.toISOString(),
          source: config.target || 'endpoint',
          event_type: 'malware_detected',
          user: 'test_user',
          source_ip: targetIp,
          country: 'USA',
          raw_log: `Simulated malware: ${config.customPayload || 'Trojan.Generic.Test'} detected`,
        });
        alerts.push({
          title: 'Simulated Malware Detection',
          description: `Malware signature detected: ${config.customPayload || 'Trojan.Generic.Test'}. This is a simulated attack for testing purposes.`,
          severity: 'critical',
          status: 'new',
          alert_type: 'malware',
          source_ip: targetIp,
          affected_asset: config.target,
          priority_score: 98,
        });
        break;

      case 'ddos':
        for (let i = 0; i < 20; i++) {
          logs.push({
            timestamp: new Date(now.getTime() - (20 - i) * 500).toISOString(),
            source: config.target || 'firewall',
            event_type: 'suspicious_traffic',
            source_ip: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
            destination_ip: targetIp,
            country: countries[Math.floor(Math.random() * countries.length)],
            raw_log: 'High volume traffic detected',
          });
        }
        alerts.push({
          title: 'Simulated DDoS Attack',
          description: `Distributed denial of service attack simulation. 20+ connections from multiple sources targeting ${targetIp}`,
          severity: 'critical',
          status: 'new',
          alert_type: 'suspicious_activity',
          source_ip: sourceIp,
          affected_asset: config.target,
          priority_score: 92,
        });
        break;

      case 'port_scan':
        for (let i = 0; i < 10; i++) {
          logs.push({
            timestamp: new Date(now.getTime() - (10 - i) * 1000).toISOString(),
            source: config.target || 'firewall',
            event_type: 'suspicious_traffic',
            source_ip: sourceIp,
            destination_ip: targetIp,
            country: country,
            raw_log: `Port ${20 + i * 10} scan detected from ${sourceIp}`,
          });
        }
        alerts.push({
          title: 'Simulated Port Scanning Activity',
          description: `Network reconnaissance detected. Sequential port scanning from ${sourceIp}. Country: ${country}`,
          severity: 'high',
          status: 'new',
          alert_type: 'suspicious_activity',
          source_ip: sourceIp,
          country: country,
          priority_score: 75,
        });
        break;

      case 'privilege_escalation':
        logs.push({
          timestamp: now.toISOString(),
          source: config.target || 'server',
          event_type: 'privilege_escalation',
          user: 'test_service',
          source_ip: targetIp,
          country: 'USA',
          raw_log: 'Simulated unauthorized privilege escalation attempt',
        });
        alerts.push({
          title: 'Simulated Privilege Escalation',
          description: 'Service account attempted to gain elevated privileges without authorization. Simulated attack for testing.',
          severity: 'high',
          status: 'new',
          alert_type: 'privilege_abuse',
          source_ip: targetIp,
          affected_user: 'test_service',
          priority_score: 85,
        });
        break;

      case 'data_exfiltration':
        logs.push({
          timestamp: now.toISOString(),
          source: config.target || 'server',
          event_type: 'data_exfiltration',
          user: 'backup_test',
          source_ip: targetIp,
          destination_ip: sourceIp,
          country: country,
          raw_log: `Large data transfer detected: ${config.customPayload || '500MB'} to ${sourceIp}`,
        });
        alerts.push({
          title: 'Simulated Data Exfiltration',
          description: `Unauthorized data transfer detected. ${config.customPayload || '500MB'} transferred to external IP ${sourceIp}`,
          severity: 'critical',
          status: 'new',
          alert_type: 'data_breach',
          source_ip: targetIp,
          country: country,
          priority_score: 90,
        });
        break;
    }

    return { logs, alerts };
  };

  const runAttack = async () => {
    if (!selectedAttack) return;

    setIsRunning(true);
    setProgress(0);

    try {
      // Simulate attack execution with progress
      const duration = parseInt(config.duration) * 1000;
      const steps = 20;
      const stepDelay = duration / steps;

      for (let i = 0; i <= steps; i++) {
        await new Promise(resolve => setTimeout(resolve, stepDelay));
        setProgress((i / steps) * 100);
      }

      // Generate attack data
      const { logs, alerts } = generateAttackData(selectedAttack);

      // Create logs
      for (const log of logs) {
        await base44.entities.SecurityLog.create(log);
      }

      // Create alerts
      for (const alert of alerts) {
        await base44.entities.Alert.create(alert);
      }

      // Invalidate queries to refresh data
      queryClient.invalidateQueries(['logs']);
      queryClient.invalidateQueries(['alerts']);

      toast.success(`Attack simulation completed! Generated ${logs.length} logs and ${alerts.length} alerts.`);
      
      setProgress(100);
      setTimeout(() => {
        setIsRunning(false);
        setProgress(0);
        setSelectedAttack(null);
        setConfig({
          target: '',
          targetIp: '',
          intensity: 'medium',
          duration: '5',
          customPayload: '',
        });
        onComplete?.();
      }, 1000);

    } catch (error) {
      console.error('Attack simulation failed:', error);
      toast.error('Attack simulation failed');
      setIsRunning(false);
      setProgress(0);
    }
  };

  return (
    <div className="space-y-6">
      {/* Attack Type Selection */}
      {!selectedAttack && (
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          {attackTypes.map((attack, i) => {
            const Icon = attack.icon;
            return (
              <motion.div
                key={attack.id}
                className={`p-5 rounded-xl bg-black/40 border border-${attack.color}-500/30 cursor-pointer transition-all hover:border-${attack.color}-500/60 backdrop-blur-sm`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ scale: 1.02, boxShadow: `0 0 30px rgba(239, 68, 68, 0.2)` }}
                onClick={() => setSelectedAttack(attack)}
              >
                <div className={`w-12 h-12 rounded-lg bg-${attack.color}-500/20 flex items-center justify-center mb-3`}>
                  <Icon className={`w-6 h-6 text-${attack.color}-400`} />
                </div>
                <h3 className="text-white font-semibold mb-2">{attack.name}</h3>
                <p className="text-gray-400 text-sm mb-3">{attack.description}</p>
                <div className="flex flex-wrap gap-2">
                  {attack.targets.map((target) => (
                    <span key={target} className="px-2 py-1 bg-gray-800 text-gray-400 text-xs rounded">
                      {target}
                    </span>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      )}

      {/* Configuration Panel */}
      <AnimatePresence>
        {selectedAttack && !isRunning && (
          <motion.div
            className="bg-black/40 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className={`w-12 h-12 rounded-lg bg-${selectedAttack.color}-500/20 flex items-center justify-center`}>
                <selectedAttack.icon className={`w-6 h-6 text-${selectedAttack.color}-400`} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">{selectedAttack.name}</h3>
                <p className="text-gray-400 text-sm">{selectedAttack.description}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Target System</label>
                <Select value={config.target} onValueChange={(v) => setConfig({ ...config, target: v })}>
                  <SelectTrigger className="bg-black/30 border-gray-700 text-white">
                    <SelectValue placeholder="Select target" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedAttack.targets.map((target) => (
                      <SelectItem key={target} value={target}>{target}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-2 block">Target IP (Optional)</label>
                <Input
                  placeholder="192.168.1.100"
                  value={config.targetIp}
                  onChange={(e) => setConfig({ ...config, targetIp: e.target.value })}
                  className="bg-black/30 border-gray-700 text-white"
                />
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-2 block">Attack Intensity</label>
                <Select value={config.intensity} onValueChange={(v) => setConfig({ ...config, intensity: v })}>
                  <SelectTrigger className="bg-black/30 border-gray-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low (5-10 events)</SelectItem>
                    <SelectItem value="medium">Medium (10-20 events)</SelectItem>
                    <SelectItem value="high">High (20-50 events)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-2 block">Duration (seconds)</label>
                <Input
                  type="number"
                  min="1"
                  max="30"
                  value={config.duration}
                  onChange={(e) => setConfig({ ...config, duration: e.target.value })}
                  className="bg-black/30 border-gray-700 text-white"
                />
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-2 block">Custom Payload (Optional)</label>
                <Textarea
                  placeholder="Custom attack payload or notes..."
                  value={config.customPayload}
                  onChange={(e) => setConfig({ ...config, customPayload: e.target.value })}
                  className="bg-black/30 border-gray-700 text-white"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  onClick={runAttack}
                  disabled={!config.target}
                  className="flex-1 bg-red-600 hover:bg-red-700"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Launch Attack
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setSelectedAttack(null)}
                  className="border-gray-700 text-gray-400"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Running Animation */}
      <AnimatePresence>
        {isRunning && (
          <motion.div
            className="bg-black/60 backdrop-blur-sm border border-red-500/50 rounded-xl p-8"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
          >
            <div className="text-center">
              <motion.div
                className="w-20 h-20 mx-auto mb-6 rounded-full bg-red-500/20 flex items-center justify-center"
                animate={{
                  boxShadow: [
                    '0 0 30px rgba(239, 68, 68, 0.4)',
                    '0 0 60px rgba(239, 68, 68, 0.8)',
                    '0 0 30px rgba(239, 68, 68, 0.4)',
                  ],
                }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                <Zap className="w-10 h-10 text-red-400 animate-pulse" />
              </motion.div>
              
              <h3 className="text-xl font-bold text-white mb-2">Attack in Progress</h3>
              <p className="text-gray-400 mb-6">Simulating {selectedAttack?.name}...</p>
              
              <div className="max-w-md mx-auto">
                <div className="h-3 bg-gray-800 rounded-full overflow-hidden mb-2">
                  <motion.div
                    className="h-full bg-gradient-to-r from-red-500 to-orange-500"
                    style={{ width: `${progress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                <p className="text-red-400 text-sm font-mono">{Math.round(progress)}%</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}