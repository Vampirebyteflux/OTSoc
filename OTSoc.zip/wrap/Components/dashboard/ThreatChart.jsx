import React from 'react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';

export default function ThreatChart({ data }) {
  const chartData = data || [
    { time: '00:00', critical: 2, high: 5, medium: 8, low: 12 },
    { time: '04:00', critical: 4, high: 7, medium: 10, low: 15 },
    { time: '08:00', critical: 8, high: 12, medium: 18, low: 22 },
    { time: '12:00', critical: 6, high: 15, medium: 20, low: 28 },
    { time: '16:00', critical: 10, high: 18, medium: 25, low: 32 },
    { time: '20:00', critical: 5, high: 10, medium: 15, low: 20 },
    { time: '24:00', critical: 3, high: 8, medium: 12, low: 18 },
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-black/90 border border-purple-500/30 rounded-lg p-3 backdrop-blur-sm">
          <p className="text-purple-400 text-sm font-medium mb-2">{label}</p>
          {payload.map((entry, index) => (
            <div key={index} className="flex items-center gap-2 text-xs">
              <span 
                className="w-2 h-2 rounded-full" 
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-gray-400 capitalize">{entry.dataKey}:</span>
              <span className="text-white font-medium">{entry.value}</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-black/30 backdrop-blur-sm border border-purple-500/20 rounded-xl p-5">
      <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
        <motion.div
          className="w-2 h-2 rounded-full bg-purple-400"
          animate={{ scale: [1, 1.3, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        />
        Threat Activity Timeline
      </h3>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="criticalGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#ef4444" stopOpacity={0.4} />
                <stop offset="100%" stopColor="#ef4444" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="highGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f97316" stopOpacity={0.4} />
                <stop offset="100%" stopColor="#f97316" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="mediumGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#eab308" stopOpacity={0.4} />
                <stop offset="100%" stopColor="#eab308" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="lowGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#22c55e" stopOpacity={0.4} />
                <stop offset="100%" stopColor="#22c55e" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis 
              dataKey="time" 
              stroke="#6b7280" 
              tick={{ fill: '#9ca3af', fontSize: 11 }}
              axisLine={{ stroke: '#374151' }}
            />
            <YAxis 
              stroke="#6b7280"
              tick={{ fill: '#9ca3af', fontSize: 11 }}
              axisLine={{ stroke: '#374151' }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area 
              type="monotone" 
              dataKey="critical" 
              stackId="1"
              stroke="#ef4444" 
              fill="url(#criticalGrad)"
              strokeWidth={2}
            />
            <Area 
              type="monotone" 
              dataKey="high" 
              stackId="1"
              stroke="#f97316" 
              fill="url(#highGrad)"
              strokeWidth={2}
            />
            <Area 
              type="monotone" 
              dataKey="medium" 
              stackId="1"
              stroke="#eab308" 
              fill="url(#mediumGrad)"
              strokeWidth={2}
            />
            <Area 
              type="monotone" 
              dataKey="low" 
              stackId="1"
              stroke="#22c55e" 
              fill="url(#lowGrad)"
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 flex flex-wrap justify-center gap-4 text-xs">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-sm bg-red-500" />
          <span className="text-gray-400">Critical</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-sm bg-orange-500" />
          <span className="text-gray-400">High</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-sm bg-yellow-500" />
          <span className="text-gray-400">Medium</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-sm bg-green-500" />
          <span className="text-gray-400">Low</span>
        </div>
      </div>
    </div>
  );
}